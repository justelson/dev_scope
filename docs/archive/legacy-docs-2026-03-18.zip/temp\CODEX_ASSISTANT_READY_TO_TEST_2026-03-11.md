# Codex Assistant Ready-To-Test Note

Date: March 11, 2026
Status: implementation staged for manual testing

## What Is Wired

- Codex-only assistant runtime in Electron main via `codex app-server`
- assistant contracts, IPC channels, preload bridge, and renderer assistant store
- persisted assistant sessions/threads/messages/activity/proposed plans in Electron main storage
- `/assistant` route restored in the desktop app
- assistant item restored in the main sidebar
- session list, conversation timeline, composer, approval cards, user-input cards, plan panel, and activity panel

## Main Files

- `src/shared/assistant/contracts/*`
- `src/shared/assistant/projector.ts`
- `src/main/assistant/*`
- `src/main/ipc/handlers/assistant-handlers.ts`
- `src/preload/adapters/assistant-adapter.ts`
- `src/renderer/src/lib/assistant/*`
- `src/renderer/src/pages/assistant/*`

## Manual Smoke Path

1. Open the app and go to `/assistant`.
2. Create a session from the left rail.
3. Attach a folder if desired.
4. Click `Connect` or send a prompt directly.
5. Verify:
   - user message appears in the timeline
   - assistant response streams into one stable assistant row
   - approvals appear in the approvals panel
   - user-input requests appear in the input panel
   - plan updates appear in the plan panel
   - activity updates appear in the activity panel
6. Create a new thread and confirm the session keeps older thread history.
7. Reload the renderer and confirm the selected session/thread snapshot restores.
8. Restart the app and confirm sessions restore.

## Known Constraint

- No build, typecheck, or full test run was executed in this session because repo policy requires fresh user re-approval for validation commands.
